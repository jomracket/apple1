/* SimCon 2000
 * Copyright 1996,1998, Peter Rittwage
 *
 */

#include "simcon.h"

int main(int argc, char *argv[])
{
   int x,loop;

   cursor_x=cursor_y=0;
   video=1;
   trace=0;
   logevents=0;
   speed_throttle=0;

   printf("Apple I Emulator\n");
   printf("Copyright 1999, Peter Rittwage\n");
   printf("\nOriginal Apple Hardware and Monitor\n");
   printf("Copyright 1975, Steve Wozniak\n\n");


   printf("Allocating memory map\n");
   if(NULL==(mem_map=(byte *)malloc(MAPSIZE))) cleanup("out of memory");
   if(NULL==(stampset=(byte *)malloc(0x1000))) cleanup("out of memory");

   for(x=0;x<MAPSIZE;x++) mem_map[x]=0xff;

   if(!init_system()) cleanup("couldn't initialize system");
   init_graphics();
   reset_processor();
   if(!video) close_graphics();
   go_6502();
   cleanup("normal exit");
}

void cleanup(char *problem)
{
   byte x;

   if(logevents) fclose(logfile);
   if(mem_map) free(mem_map);
   if(stampset) free(stampset);

   if(video) close_graphics();

//   printf("%s\n\n",problem);
   printf("halt: 0x%04x\n",proc_PC);
   printf("irq: 0x%02x%02x\nres: 0x%02x%02x\nnmi: 0x%02x%02x\n",
      mem_map[0xfffb],mem_map[0xfffa],mem_map[0xfffd],
      mem_map[0xfffc],mem_map[0xffff],mem_map[0xfffe]);
//   printf("irqr: %d cycles/frame\n",irq_rate);
   exit(0);
}

void read_raw(byte *dest, byte *filename, int length)
{
   FILE *myfile;
   int filesize;

   if(NULL==(myfile=fopen(filename,"rb")))
      cleanup("missing rom(s)");

   filesize=fread(dest,1,length,myfile);
   if(filesize!=length)
      cleanup("problem with rom(s)");

   fclose(myfile);
}

