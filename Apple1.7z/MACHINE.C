/* Apple 1
 * Machine internals
 * (c) 1996,1998 Peter Rittwage
 */

#include "simcon.h"

void refresh(void)
{
   throttle();
   check_controls();
}

void set_palette(byte entry, byte red, byte green, byte blue)
{
}

byte read_memory(unsigned int address)
{
   char string[40];
   SDL_Event event;
   byte keycode;

   switch(address)
   {
      case 0xD010:
         mem_map[0xD011]=0x00;
         keycode=mem_map[address];
         mem_map[0xD010]=0x00;
         //sprintf(string,"%d  ",keycode);
         //Blit_String(0,24,string);
         return(keycode);
	 	 break;

      case 0xD011:
         if(mem_map[0xD010]) mem_map[0xD011]=0x80;
         Blit_Char(cursor_x*8,cursor_y*8,0x01);
         return(mem_map[address]);
         break;

      case 0xD012:
//         sprintf(string,"Read from display");
//         if(video) Blit_String(0,24,string);
//         else printf(&string);
         return(mem_map[address]);
         break;

      case 0xD013:
//         sprintf(string,"Read from display CR");
//         if(video) Blit_String(0,24,string);
//         else printf(&string);
         return(mem_map[address]);
         break;

      default:
         return(mem_map[address]);
         break;
      }
}

void set_memory(unsigned int address, byte value)
{
   char string[40];

   switch(address)
   {
      case 0xD010:
//         sprintf(string,"Wrote to keyboard");
//         if(video) Blit_String(0,24,string);
//         else printf(&string);
         break;

      case 0xD011:
//         sprintf(string,"Wrote to keyboard CR");
//         if(video) Blit_String(0,24,string);
//         else printf(&string);
         break;

      case 0xD012:
//         sprintf(string,"Wrote to display");

            if(value==0x8D) // Carriage Return
            {
               cursor_x=0;
               cursor_y++;
               if(cursor_y>23) { scroll(); cursor_y=23; }
            }
            else if(value==0x7F) // CLRSCN Command Sent
            {
              //memset(screen,0,320*200);
              //cursor_x=cursor_y=0;
            }
            else if(value==136) cursor_x--; // Backspace Pressed
            else if(value==27+0x80); // ESC Pressed
            else if(value==60+0x80); // F1 Pressed
            else if(value==61+0x80); // F2 Pressed
            else if(value==62+0x80); // F3 Pressed
            else
            {
//               Blit_String(0,24,string);
               Blit_Char(cursor_x*STAMP_XSIZE,cursor_y*STAMP_YSIZE,value&=0x7F);
               cursor_x++;
               if(cursor_x>39) { cursor_x=0; cursor_y++; }
               if(cursor_y>23) { scroll(); cursor_y=23; }
            }
//         else printf(&string);
         	break;

      case 0xD013:
//         sprintf(string,"Wrote to display CR");
//         if(video) Blit_String(0,24,string);
//         else printf(&string);
         break;

      default:
         mem_map[address]=value;
         break;
   }
   return;
}

void check_controls(void)
{
	SDL_Event event;
	int keycode;

	while ( SDL_PollEvent(&event) ) {
		switch (event.type) {
			case SDL_MOUSEMOTION:
				printf("Mouse moved by %d,%d to (%d,%d)\n",
					event.motion.xrel, event.motion.yrel,
					event.motion.x, event.motion.y);
				break;
			case SDL_MOUSEBUTTONDOWN:
				printf("Mouse button %d pressed at (%d,%d)\n",
					event.button.button, event.button.x, event.button.y);
				break;
			case SDL_KEYDOWN:
				keycode=event.key.keysym.sym+0x80;
				if((keycode>=224)&&(keycode<=255)) keycode=keycode-32;  /* Auto CAPSLOCK */
				if(keycode==187) keycode=186;
				if(keycode==155) { keycode=127; force_nmi=1; };
				mem_map[0xD010]=keycode;
				break;
			case SDL_QUIT:
				exit(0);

	        }
	}
}

int init_system(void)
{
   int x;

   read_raw(&mem_map[0xFF00],"apple1.rom",0x0100);
   read_raw(&stampset[0],"apple1.vid",0x0400);

   irq=FALSE;
   nmi=FALSE;

   cpu_rate=1000000;   /* 1.000MHz */
   irq_rate=cpu_rate/FRAMES_PER_SECOND;

   mem_map[0xD010]=0x00;
   mem_map[0xD011]=0x00;
   mem_map[0xD012]=0x00;
   mem_map[0xD013]=0x00;

   set_palette(255,63,63,63);

   return(TRUE);
}


