#include "simcon.h"


void throttle(void)
{
}

void scroll(void)
{
   int index;
   unsigned char *tmp;

	SDL_LockSurface(screen);

	tmp= ((Uint8*)screen->pixels);

   for(index=0;index<23;index++)
      memcpy(tmp+(index*320*8),tmp+((index+1)*8*320),320*8);

   memset(tmp+(23*320*8-1),0,320*8-1);

   	SDL_UnlockSurface(screen);
	SDL_Flip(screen);
//   Blit_Char(26*STAMP_XSIZE,24*STAMP_YSIZE,'S');
}

void Blit_Char(int xc, int yc, char c)
{
   int offset,x,y;
   unsigned char *work_char;
   unsigned char bit_mask = 0x80;

   work_char = stampset + (c * 8);
   offset = (yc << 8) + (yc << 6) + xc;

	if (SDL_LockSurface(screen) <0 ) {};

   for (y=0; y<8; y++)
   {
      bit_mask = 0x80;
      for (x=8; x>0; x--)
      {
		 unsigned char*tmp= ((Uint8*)screen->pixels);
         if ((*work_char & bit_mask)) tmp[offset+x]=255;
         else tmp[offset+x]=0;

         bit_mask = (bit_mask>>1);
      }
      offset += 320;
      work_char++;
   }

	SDL_UnlockSurface(screen);
	SDL_Flip(screen);
}

void Blit_String(int x, int y, char *string)
{
   int index;

   for(index=0; string[index]!=0; index++)
      Blit_Char(((x*STAMP_XSIZE)+(index<<3)),y*STAMP_YSIZE,string[index]);
}

int init_graphics(void)
{
	Uint32 video_flags;

	  /* Inizialize the SDL library */
	  if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
	    fprintf(stderr, "Couldn't initialize SDL: %s\n", SDL_GetError());
	    return 1;
	  }

	  /* fire and forget... */
	  atexit(SDL_Quit);

	  video_flags = (SDL_SWSURFACE|SDL_HWPALETTE);
	  screen=SDL_SetVideoMode(320, 200, 8, video_flags);
	    if ( screen == NULL ) {
	      fprintf(stderr, "Couldn't initialize video mode: %s\n", SDL_GetError());
	      return 1;
	    }
//	    SDL_EventState(SDL_ACTIVEEVENT, SDL_IGNORE);
 // 		SDL_EventState(SDL_MOUSEMOTION, SDL_IGNORE);
	return(0);
}

void close_graphics(void)
{
}

